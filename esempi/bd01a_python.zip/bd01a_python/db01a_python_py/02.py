n = input('inserisci il tuo nome: ')
print('ciao',n)
