# esempio semplice calcolatrice
a = float(input('primo valore: '))
b = float(input('secondo valore: '))
op = input('operazione da effettuare (+-*/): ')

if op == '+':
    print(a + b)
elif op == '-':      # altrimenti se ...
    print(a - b)
elif op == '*':
    print(a * b)
elif op == '/' and b != 0:
    print(a / b)
else:                # se nessuna condizione è verificata
    print("operazione non ammessa")
