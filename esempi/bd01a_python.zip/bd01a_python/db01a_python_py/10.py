contatore = 0     # ho ricevuto 0 valori in input
somma = 0         # quindi la somma vale 0
while contatore < 5:
    n = float(input('inserisci un valore: '))
    somma = somma + n         # sommo agli altri il valore di n
    contatore = contatore + 1 # ho ricevuto un numero in più
media = somma / 5
print('media =',media)
