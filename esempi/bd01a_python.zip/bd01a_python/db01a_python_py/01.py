# hello world
print("hello world")   #visualizza (print) la stringa di caratteri "hello world"
