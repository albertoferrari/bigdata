# area triangolo
# input(prompt) visualizza il prompt, richiede una sequenza di caratteri
# float(val) converte in valore numerico "decimale" val
# a = b alla variabile a assegna il valore dell'espressione b
base = float(input("base del triangolo: "))
alt = float(input("altezza del triangolo: "))
area = base * alt / 2
print("area del triangolo", area)   # print(a,b)
