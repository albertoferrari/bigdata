print("2  * 5 = ", 2  * 5)             # moltiplicazione
print("2 ** 5 = ", 2 ** 5)             # elevamento a potenza
print("2 ** 0.5 = ", 2 ** 0.5)         # potenza anche decimale (radice quadrata)
print("28 // 5 = ",28 // 5)            # divisione intera
print("28  % 5 = ",28  % 5)            # resto della divisione intera
print("28  / 5 = ",28  / 5)            # divisione
print("3 >  3 = ",3 >  3)              # confronto maggiore
print("3 >= 3 = ",3 >= 3)              # confronto maggiore o uguale
print("True and False = ", True and False)   # connettivo logico and
print("True  or False = ", True  or False)   # connettivo logico or
print("not True = ", not True)               # negazione
