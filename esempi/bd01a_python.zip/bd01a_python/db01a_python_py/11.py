val = [3,4,2,5.5,-3,4,12]          # valori racchiusi fra [] e separati da virgole
print(val)                         # visualizzazione di tutti i valori
for e in val:                      # per ogni elementi e della lista val
    print(e*2)                     # visualizza il valore doppio dell'elemento
