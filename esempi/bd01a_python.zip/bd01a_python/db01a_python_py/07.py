x = float(input("inserisci un valore: "))

if x >= 0:
    y = x
    print(x, "è positivo")
else:         # blocco eseguito se la condizione è falsa
    y = -x
    print(x, "è negativo")

print("il valore assoluto di x è", y)
