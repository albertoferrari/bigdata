a = int(input('inserisci un valore il cui quadrato sia minore di 100: '))
if a**2 < 100:
    print('corretto')
print('errato: il quadrato del valore che hai inserito:',a,'vale:',a**2)
