val = [3,4,2,5.5,-3,4,12] 
max = val[0]                 # v[i] elemento di indice (posizione) i della lista v 
                             # il primo elemento ha indice 0
min = val[0]
somma = 0
for v in val:                # per ogni elemento v in val
    if v > max:
        max = v              # trovato un nuovo massimo
    if v < min:
        min = v              # trovato un nuovo minimo
    somma = somma + v        # sommo v ai precedenti valori
media = somma / len(val)     # len(val) numero di elementi della lista val
print('massimo:',max,' minimo:',min,' media:',media)
