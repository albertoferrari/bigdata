print("somma dei numeri da 1 a n")
n = int(input("valore di n: "))
somma = 0         # somma dei valori inseriti
cont = 1          # valore da sommare

while cont <= n:                   # fintanto che la condizione è verificata esegue il blocco
    somma = somma + cont
    cont = cont + 1

print("la somma dei numeri da 1 a",n,"è =",somma)
