eta = int(input("età: "))
if eta < 14:          # se la condizione è vera (true) vengono eseguite le istruzioni del blocco
    # le istruzioni che compongono il blocco devono essere indentate
    print("sei troppo giovane per guidare uno scooter...")
    print("ma non per imparare Python!")
print('fine programma')
