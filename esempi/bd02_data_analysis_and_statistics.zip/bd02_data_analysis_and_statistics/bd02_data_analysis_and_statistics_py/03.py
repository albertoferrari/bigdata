import random

# choice(lista)
# restituisce un elemento scelto casualmente da una lista
semi = ['cuori','quadri','fiori','picche']
print(random.choice(semi))
