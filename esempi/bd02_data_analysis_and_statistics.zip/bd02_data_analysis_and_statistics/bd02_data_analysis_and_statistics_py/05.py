# supponendo di vincere 1 euro ogni volta in cui il risultato è 5 o 6 
# e di perdere un euro ogni volta in cui il risultato è 1 o 2 
# calcolare la vincita o perdita totale
import random

risultati = []             # lista vuota
for i in range(20):        # per 20 volte (valori di i da 0 a 19)
    r = random.randint(1,6)
    risultati.append(r)
print(risultati)

portafoglio = 0            # situazione iniziale
for n in risultati:        # per ogni elemento della lista
    if 5 <= n <= 6:
        portafoglio = portafoglio + 1
    elif 1 <= n <= 2:
        portafoglio = portafoglio - 1
if portafoglio > 0:
    print('hai vinto',portafoglio,'euro')
elif portafoglio < 0:
    print('hai perso',-portafoglio,'euro')
else:
    print('non hai nè vinto nè perso')
