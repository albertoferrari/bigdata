# utilizzo libreria
import random
# help(random)

# random() genera un valore casuale compreso fra 0 e 1
n = random.random()
print(n)
# inserimento di 10 valori in una lista
l = []
for i in range(10):
    n = random.random()
    l.append(n)
print(l)
