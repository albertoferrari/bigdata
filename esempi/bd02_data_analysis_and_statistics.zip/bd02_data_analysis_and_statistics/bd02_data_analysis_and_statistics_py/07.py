import random
import statistics

# 10 valori casuali nell'intervallo [5,20]
val = []
for i in range(10):
    v = random.randint(5,20)
    val.append(v)
print(val)
print('_______________________________________________')

media = statistics.mean(val)
print('media',media)
mediana = statistics.median(val)
print('mediana',mediana)
moda = statistics.mode(val)
print('moda',moda)
dev_standard = statistics.stdev(val)
print('deviazione standard',dev_standard)



