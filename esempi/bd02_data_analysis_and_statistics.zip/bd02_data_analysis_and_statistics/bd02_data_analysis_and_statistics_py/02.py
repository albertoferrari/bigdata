# utilizzo libreria
import random
# randint(min,max)
# restituisce un numero intero compreso fra min (incluso) e max (incluso)

l = []
for i in range(10):
    n = random.randint(3, 9)
    l.append(n)
print(l)
