# normalizzazione

import random
x = [random.randint(1,100) for i in range(10)]
print('valori',x)
# calcolo del massimo e minimo
mi = x[0]       # inizializzazione minimo
ma = x[0]       # inizializzazione massimo
for v in x:
    if v < mi:
        mi = v
    if v > ma:
        ma = v
print('minimo',mi,'massimo',ma)
for i in range(len(x)):
    x[i] = (x[i]-mi) / (ma - mi)
print('valori normalizzati')
# print(x)
for i in range(len(x)):               # formattazione output (3 decimali)
    print('%.3f' % x[i], end=' ')


