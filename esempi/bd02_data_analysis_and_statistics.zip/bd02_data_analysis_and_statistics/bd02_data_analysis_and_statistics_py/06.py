import random

# 10 valori casuali nell'intervallo [5,20]
val = []
for i in range(10):
    v = random.randint(5,20)
    val.append(v)
print(val)
print('_______________________________________________')

#media
somma = 0
for v in val:
    somma = somma + v
n_val = len(val)
media = somma / n_val
print('media',media)
print('_______________________________________________')

#mediana
print('valori iniziali',val)
m = val[:]                        # copia dei valori
m.sort()                          # ordina i valori
print('valori ordinati',m)        # stampa valori ordinati
if len(m) % 2 != 0:               # lunghezza dispari
    med = m[len(m)//2]
else:
    med = (m[len(m)//2 - 1] + m[len(m)//2]) / 2
print('mediana',med)
print('_______________________________________________')

#deviazione standard
print('valori',val)

# calcolo della media
somma = 0
for v in val:
    somma = somma + v
n_val = len(val)
media = somma / n_val
print('media',media)

# calcolo della deviazione standard
somma_q = 0      # somma dei quadrati
for v in val:    # per ogni elemento
    somma_q += (v - media) ** 2
somma_q = somma_q / n_val
ds = somma_q ** 0.5
print('deviazione standard',ds)
print('_______________________________________________')

#moda
import statistics
print(val)
moda = statistics.mode(val)
print('moda',moda)
print('_______________________________________________')



