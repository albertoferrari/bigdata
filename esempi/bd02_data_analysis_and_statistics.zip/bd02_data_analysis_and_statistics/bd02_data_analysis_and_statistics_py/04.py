# simulazione lancio di un dado 20 volte
import random
risultati = []             # lista vuota
for i in range(20):        # per 20 volte (valori di i da 0 a 19)
    r = random.randint(1,6)
    risultati.append(r)
print(risultati)

