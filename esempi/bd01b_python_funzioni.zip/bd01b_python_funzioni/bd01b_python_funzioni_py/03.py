# modulo per valori pseudocasuali
from random import randint
lancio1 = randint(1, 6)  # simulazione lancio del primo dado
lancio2 = randint(1, 6)  # simulazione lancio secondo dado
print('primo dado',lancio1,'secondo dado',lancio2)
