# importazione della libreria math (modulo math)
# che contiene la funzione sqrt (radice quadrata)
import math
def ipotenusa(a, b):
    '''
    calcola e restituisce l'ipotenusa di un triangolo
    rettangolo con cateti a b
    '''
    c = math.sqrt(a ** 2 + b ** 2)
    return c

cat1 = float(input('lunghezza primo cateto: '))
cat2 = float(input('lunghezza secondo cateto: '))
ipot = ipotenusa(cat1, cat2)
print("l'ipotenusa di un triangolo rettangolo con cateti",cat1,cat2,'è uguale a',ipot)
