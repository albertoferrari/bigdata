# dal modulo math importazione della funzione seno e della costante pi greco
from math import sin, pi
print(sin(pi / 4))
