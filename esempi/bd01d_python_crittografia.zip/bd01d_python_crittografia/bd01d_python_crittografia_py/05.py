alfabeto = "abcdefghijklmnopqrstuvwxyz"
chiave = 5
prima_parte = alfabeto[0:chiave]       #alfabeto fino a chiave
seconda_parte = alfabeto[chiave:]      #alfabeto da chiave in poi
cifrato = seconda_parte + prima_parte  #composizione alfabeto
print(alfabeto)
print(cifrato)

testo = "big data"
testo_cifrato = ""
for c in testo:
    pos = alfabeto.find(c)
    if pos == -1:
        testo_cifrato = testo_cifrato + c
    else:
        testo_cifrato = testo_cifrato + cifrato[pos]
print('il testo:           ',testo)
print('viene crittato come:',testo_cifrato)
