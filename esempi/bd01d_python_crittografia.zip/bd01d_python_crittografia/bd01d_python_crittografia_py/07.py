import hashlib
frase = "big data"
testo_cifrato = hashlib.md5(frase.encode())

print("testo cifrato in caratteri esadecimali : ", testo_cifrato.hexdigest())
