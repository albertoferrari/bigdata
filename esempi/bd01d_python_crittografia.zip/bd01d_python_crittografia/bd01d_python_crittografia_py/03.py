# Cesare (chiave fissa con valore 3)
# crittare il messaggio
alfabeto = "abcdefghijklmnopqrstuvwxyz"
cifrato =  "defghijklmnopqrstuvwxyzabc"
testo = "big data"
testo_cifrato = ""
for c in testo:
    pos = alfabeto.find(c)
    if pos == -1:
        testo_cifrato = testo_cifrato + c
    else:
        testo_cifrato = testo_cifrato + cifrato[pos]
print('il testo:           ',testo)
print('viene crittato come:',testo_cifrato)
