# atbash
# decrittare il messaggio
alfabeto = "abcdefghijklmnopqrstuvwxyz"
cifrato =  "zyxwvutsrqponmlkjihgfedcba"
testo_cifrato = "yrt wzgz"
testo_decifrato = ""
for c in testo_cifrato:
    pos = alfabeto.find(c)
    if pos == -1:
        testo_decifrato = testo_decifrato + c
    else:
        testo_decifrato = testo_decifrato + cifrato[pos]
print('il testo crittato:    ',testo_cifrato)
print('viene decrittato come:',testo_decifrato)
