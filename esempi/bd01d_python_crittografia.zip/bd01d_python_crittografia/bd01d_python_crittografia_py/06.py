def cesare_critta(t,k):
    '''
    restituisce il testo t
    crittato con il metodo di Cesare
    con chiave k
    '''
    alfabeto = "abcdefghijklmnopqrstuvwxyz"
    prima_parte = alfabeto[0:k]
    seconda_parte = alfabeto[k:]
    cifrato = seconda_parte + prima_parte
    testo_cifrato = ""
    for c in t:
        pos = alfabeto.find(c)
        if pos == -1:
            testo_cifrato = testo_cifrato + c
        else:
            testo_cifrato = testo_cifrato + cifrato[pos]
    return testo_cifrato

t_chiaro = input('testo da cifrare: ')
ch = int(input('chiave: '))
t_cifrato = cesare_critta(t_chiaro,ch)
print('testo cifrato:',t_cifrato)
