# atbash
# crittare il messaggio
alfabeto = "abcdefghijklmnopqrstuvwxyz"
cifrato =  "zyxwvutsrqponmlkjihgfedcba"
testo = "big data"
testo_cifrato = ""
for c in testo:
    pos = alfabeto.find(c)      # posizione del catattere c nella stringa alfabeto
    if pos == -1:               # -1 se non trovato
        testo_cifrato = testo_cifrato + c
    else:
        testo_cifrato = testo_cifrato + cifrato[pos]
print('il testo:           ',testo)
print('viene crittato come:',testo_cifrato)
