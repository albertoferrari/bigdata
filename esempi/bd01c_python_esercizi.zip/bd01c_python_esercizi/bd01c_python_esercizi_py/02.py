# categorie di età (decadi)
decade = [0,0,0,0,0,0,0,0,0,0]
eta = int(input('età: '))
while eta>0:
    d = eta // 10
    decade[d] = decade[d] + 1
    eta = int(input('età: '))
print(decade)
