# raggruppare in base all'età
giovani = 0
menoGiovani = 0
eta = int(input('età: '))
while eta>0:
    if eta < 30:
        giovani = giovani +1
    else:
        menoGiovani = menoGiovani + 1
    eta = int(input('età: '))
print('giovani',giovani,'meno giovani',menoGiovani)
