from random import randint
decade = [0] * 10
eta = randint(0, 99)  # valore casuale compreso fra 0 e 99
while eta > 0:
    d = eta // 10
    decade[d] = decade[d] + 1
    eta = randint(0, 99)
print(decade)
