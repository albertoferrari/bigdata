import csv

with open("dati_covid.csv", 'r') as f:
    for riga in csv.DictReader(f):
        print(riga)
