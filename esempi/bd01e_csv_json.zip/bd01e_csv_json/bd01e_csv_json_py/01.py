import csv                                        # modulo per gestione file csv
dati = []                                         # lista che conterrà i dati letti dal file csv
with open('dati_covid.csv',newline='') as f:      # in memoria il file ha nome f
    contenuto = csv.reader(f)                     # lettura di tutto il file
    for riga in contenuto:                        # per ogni riga
        dati.append(riga)                         # inserimento della registrazione nella lista
# dati è una lista che contiene un elemento per ogni riga del file
n_righe = len(dati)
print('numero di righe del file = numero di elementi della lista =',n_righe)
# la prima riga del file (il primo elemento della lista contiene gli attributi)
attributi = dati[0]
# attributi è una lista (dati è una lista di lista)
print(attributi)
print('_________________________________________')
n_att = len(attributi)
print('gli attributi sono',n_att)
# possiamo accedere a ognuno degli attributi attraverso un indice
for i in range(n_att):
    print(i,attributi[i])
# la seconda riga (il secondo elemento della lista dati) [indice 1]
# contiene i dati della prima registrazione
reg1 = dati[1]
print('prima registrazione')
print('___________________________________')
print(reg1)
# la millesima registrazione 
regM = dati[1000]
print('millesima registrazione')
print('___________________________________')
print(regM)
# attributi contiene n_att attributi (features)
# reg1 contiene i dati della prima registrazione
print('nome attributo - valore')
for i in range(n_att):             # i conterrà i valori da 0 a n_att-1
    print(attributi[i], ' = ',reg1[i])
print('nome attributo - valore')
for i in range(n_att):
    print(attributi[i], ' = ',regM[i])
