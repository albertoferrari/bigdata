import json
dati_covid = json.load(open("dpc-covid19-ita-andamento-nazionale.json"))
print('numero record',len(dati_covid))
riga = dati_covid[-1]
print('ultimo record')
print(riga)

print('______________________________________________')

print('attributi:')
print()
for k in riga.keys():                #keys sono le chiavi del dizionario
  print(k)

print('______________________________________________')

for att, val in riga.items():                 #items restituisce le coppie chiave valore
  print(att,' --- ',val)
  
print('______________________________________________')

# visualizzazione dettagliata del record 100
for att, val in dati_covid[100].items():
  print(att,' --- ',val)

print('______________________________________________')

# visualizzazione data e totale positivi
n = int(input('numero registrazione (1..590)'))
rn = dati_covid[n]
print('registrazione',n,'data',rn['data'],'totale positivi',rn['totale_positivi'])
