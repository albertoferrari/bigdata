import csv                                        # modulo per gestione file csv
dati = []                                         # lista che conterrà i dati letti dal file csv
with open('dati_covid.csv',newline='') as f:      # in memoria il file ha nome f
    contenuto = csv.reader(f)                     # lettura di tutto il file
    for riga in contenuto:                        # per ogni riga
        dati.append(riga)                         # inserimento della registrazione nella lista

# Selezione dei dati relativi alla provincia di Parma
# la colonna di indice 6 (attributo di indice 6) contiene la sigla della provoncia
dati_completi_Parma = []                     #lista vuota
for r in dati:
    if (r[6] == 'PR'):                       #se la provincia è parma
        dati_completi_Parma.append(r)        #aggiungo alla lista
n_PR = len(dati_completi_Parma)
print('i dati relativi a Parma sono',n_PR)

print('______________________________________________')
print('primo dato relativo a Parma')
print(dati_completi_Parma[0])
print('______________________________________________')
print('ultimo dato relativo a Parma')
print(dati_completi_Parma[-1])
print('______________________________________________')

# Selezione della data e del numero di casi
dati_sintetici_Parma = []
for r in dati_completi_Parma:
    rec = [r[0],r[9]]            # solo data (colonna 0) e numero casi (colonna 9)
    dati_sintetici_Parma.append(rec)
print('data                   ','numero casi')
for r in dati_sintetici_Parma:   # per ogni riga
    print(r)
print('______________________________________________')
# Aggiunta dell'attributo incremento_casi
dsp = dati_sintetici_Parma           # copia dei dati ottenuti precedentemente
dsp[0].append(str(0))                # primo record nessun incremento
nr = len(dsp)                        # numero record
for i in range(1,nr):
    rp = int(dsp[i-1][1])            # valore della registrazione precedente
    ra = int(dsp[i][1])              # valore della registrazione attuale
    dsp[i].append(str(ra-rp))        # inserimento dati incremento casi
print('data                   ','numero casi','incremento')
for r in dsp:
    print(r)
print('______________________________________________')
# formattazione per migliorare la leggibilità
for r in dsp:                               # per ogni riga
    data = r[0]                             # la data è il primo valore
    casi = r[1]                             # il numero di casi è il secondo valore
    incremento = r[2]                       # l'incremento è il terzo valore
    # la data è una stringa, i caratteri 8 e 9 rappresentano il giono
    giorno = data[8:10]
    # i caratteri 5 e 6 il mese
    mese = data[5:7]
    ggmm = giorno + '/' + mese
    print(ggmm,'numero casi',casi,'incremento',incremento)
print('______________________________________________')
